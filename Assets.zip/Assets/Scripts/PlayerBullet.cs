using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerBullet : MonoBehaviour
{
    float speed = 5f;   
    void Start(){
        StartCoroutine(despawn());
    }
    void Update(){
        transform.position += transform.up * speed * Time.deltaTime;
        if(Player.insideCell || Player.dead || Player.transitioning){
            Destroy(gameObject);
        }
    }
    IEnumerator despawn(){
        yield return new WaitForSeconds(5);
        Destroy(gameObject);
    }
}
