using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
public class TextFade : MonoBehaviour
{
    public TextMeshProUGUI thing;
    float opacity = 1.0f;
    int direction = -1;
    float speed = 0.02f;
    void Start()
    {
        
    }
    void FixedUpdate()
    {
        thing.color = new Color(1.0f, 1.0f, 1.0f, opacity);
        opacity += direction * speed;
        if(opacity <= 0.0f){
            opacity = 0.0f;
            direction = 1;
        }
        if(opacity >= 1.0f){
            opacity = 1.0f;
            direction = -1;
        }
    }
}
