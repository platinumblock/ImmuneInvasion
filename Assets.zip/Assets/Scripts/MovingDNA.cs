using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovingDNA : MonoBehaviour
{
    float speed = 2f;
    GameObject player;
    void Start(){
        player = GameObject.Find("Player");
        int index = transform.GetSiblingIndex();
        transform.SetSiblingIndex (index - 21);
    }
    void Update(){
        if(!Player.stopDNA) transform.position += transform.right * Time.deltaTime * speed;
        if(transform.position.x > player.transform.position.x + 6f){
            Destroy(gameObject);
        }
        if(!Player.mutating) Destroy(gameObject);
    }
}
