using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering.PostProcessing;
public class Cell : MonoBehaviour
{
    float maxHealth = 600f;
    public float health = 600f;
    public bool dying = false;
    public GameObject healthBar;
    public ParticleSystem ps;
    bool already = false;
    AudioSource sound;
    void Start(){
        sound = GetComponent<AudioSource>();
    }
    void Update(){
        
    }
    void FixedUpdate(){
        if(dying && !already){
            health -= 1f;
            healthBar.transform.localScale = new Vector3(5 * (health / maxHealth), 0.1f, 1);
            if(health/maxHealth <= 0.66f){
                healthBar.GetComponent<SpriteRenderer>().color = new Color(255, 255, 0);
            }
            if(health/maxHealth <= 0.33f){
                healthBar.GetComponent<SpriteRenderer>().color = new Color(255, 0, 0);
            }
            if(health <= 0){
                Player.activationLevel += 3;
                Player.cellsDestroyed += 1;
                sound.Play(0);
                Destroy(transform.GetChild(1).gameObject);
                ps.Play();
                Camera.main.GetComponents<PostProcessVolume>()[2].weight = 0;
                Player.insideCell = false;
                already = true;
                StartCoroutine(die());
            }
        }
    }
    IEnumerator die(){
        yield return new WaitForSeconds(1f);
        Destroy(gameObject);
    }
}
