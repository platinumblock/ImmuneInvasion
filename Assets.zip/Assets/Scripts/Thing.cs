using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class Thing : MonoBehaviour
{
    bool transitioning = false;
    public GameObject transition;
    AudioSource sound;
    void Start()
    {
        sound = GetComponent<AudioSource>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    void FixedUpdate(){
        if(transitioning){
            transition.transform.localScale = new Vector3(transition.transform.localScale.x + 80, transition.transform.localScale.y, transition.transform.localScale.z);
        }
    }
    public void play(){
        transitioning = true;
        sound.Play(0);
        StartCoroutine(next());
    }
    IEnumerator next(){
        yield return new WaitForSeconds(1);
        SceneManager.LoadScene("Game");
    }
}
