using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Particle : MonoBehaviour
{
    float maxSpeedY = 0.25f;
    float speedY;
    int directionY = -1;
    float maxSpeedX = 0.25f;
    float speedX;
    int directionX = -1;
    void Start()
    {
        speedY = Random.Range(-maxSpeedY, maxSpeedY);  
        speedX = Random.Range(-maxSpeedX, maxSpeedX);    
    }
    void Update()
    {
        transform.position += transform.up * speedY * Time.deltaTime;
        speedY += directionY * Random.Range(0.001f, 0.005f);
        if(speedY < -maxSpeedY){
            directionY = 1;
        }
        if(speedY > maxSpeedY){
            directionY = -1;
        }
        transform.position += transform.right * speedX * Time.deltaTime;
        speedX += directionX * Random.Range(0.001f, 0.005f);
        if(speedX < -maxSpeedX){
            directionX = 1;
        }
        if(speedX > maxSpeedX){
            directionX = -1;
        }
    }
}
