using System.Collections;
using System.Collections.Generic;
using System;
using UnityEngine;
using TMPro;
using UnityEngine.Rendering.PostProcessing;
using UnityEngine.SceneManagement;
public class Player : MonoBehaviour
{
    float speed = 3f;
    float speedX = 0;
    float speedY = 0;
    bool movingUp = false;
    bool movingDown = false;
    bool movingRight = false;
    bool movingLeft = false;
    bool shooting = false;
    Vector3 moveVector = new Vector3(0, 0, 0);
    Rigidbody2D rb;
    public GameObject playerBullet;
    public static float health = 100f;
    public TextMeshProUGUI healthText;
    public TextMeshProUGUI activationText;
    bool takingDamage = false;
    public GameObject camera;
    PostProcessVolume ppv;
    bool canShoot = true;
    public static bool insideCell = false;
    public ParticleSystem ps;
    public static bool dead = false;
    public GameObject deathPanel;
    public static int activationLevel = 1;
    float nextLevel = 15f;
    public GameObject mutationPanel;
    public GameObject[] dnas;
    public GameObject[] movingdnas;
    public static bool mutating = false;
    float startTime;
    public static bool stopDNA = false;
    public ParticleSystem[] mutateParticles;
    public GameObject failText;
    public GameObject successText;
    public TextMeshProUGUI mutationsText;
    public TextMeshProUGUI mutationsCountdown;
    bool successAnimation = false;
    public static bool invisible = false;
    bool speedy = false;
    bool rapidFire = false;
    public static bool hypnosis = false;
    bool immunity = false;
    bool animatingMutationsText = false;
    bool alreadyMutated = false;
    List<string> mutations = new List<string>();
    bool activeMutation = false;
    public GameObject instructionsText;
    public GameObject instructionsText2;
    public TextMeshProUGUI rankText;
    public TextMeshProUGUI statsText;
    public static int cellsDestroyed = 0;
    public static int areasInfected = 1;
    public static bool transitioning = false;
    bool antitransitioning = true;
    public GameObject transition;
    AudioSource sound;
    AudioSource sound2;
    AudioSource sound3;
    AudioSource sound4;
    AudioSource sound5;
    AudioSource sound6;
    AudioSource sound7;
    AudioSource sound8;
    void Start(){
        rb = GetComponent<Rigidbody2D>();
        ppv = camera.GetComponents<PostProcessVolume>()[1];
        StartCoroutine(activate());
        healthText.text = "" + Mathf.Round(health);
        sound = GetComponents<AudioSource>()[0];
        sound2 = GetComponents<AudioSource>()[1];
        sound3 = GetComponents<AudioSource>()[2];
        sound4 = GetComponents<AudioSource>()[3];
        sound5 = GetComponents<AudioSource>()[4];
        sound6 = GetComponents<AudioSource>()[5];
        sound7 = GetComponents<AudioSource>()[6];
        sound8 = GetComponents<AudioSource>()[7];
    }
    void Update(){
        if(!dead){
            processInput();
            updateSpeed();
            updateDirection();
            if(!mutating){
                updatePosition();
            }
        }
        if(mutating && !insideCell){
            stopDNA = true;
            foreach(ParticleSystem p in mutateParticles){
                p.Play();
            }
            mutating = false;
            failText.SetActive(false);
            StartCoroutine(abc());
        }
    }
    void FixedUpdate(){
        if(shooting && canShoot && !insideCell){
            Vector3 mouse = Input.mousePosition;
            mouse.z = 0;
            Vector3 newMouse = Camera.main.ScreenToWorldPoint(mouse);
            Vector3 rotation = new Vector3(0, 0, -90 + Mathf.Rad2Deg * Mathf.Atan((newMouse.y - transform.position.y) / (newMouse.x - transform.position.x)) + (newMouse.x - transform.position.x < 0 ? 180 : 0));
            Instantiate(playerBullet, transform.position, Quaternion.Euler(rotation));
            sound.Play(0);
            StartCoroutine(cooldown());
        }
        activationText.text = "" + activationLevel;
        if(takingDamage && !dead && !immunity){
            health -= 0.4f;
            healthText.text = "" + Mathf.Round(health);
            ppv.weight += 0.01f;
            sound2.Play(0);
            if(health <= 0f){
                ps.Play();
                Destroy(transform.GetChild(0).gameObject);
                ppv.weight = 0;
                int score = cellsDestroyed * areasInfected;
                if(score == 0){
                    rankText.text = "F";
                }else if(score <= 2){
                    rankText.text = "D";
                }else if(score <= 5){
                    rankText.text = "C";
                }else if(score <= 10){
                    rankText.text = "B";
                }else if(score <= 20){
                    rankText.text = "A";
                }else{
                    rankText.text = "S";
                }
                statsText.text = "Cells Destroyed: " + cellsDestroyed + "\nAreas Infected: " + areasInfected;
                camera.GetComponents<PostProcessVolume>()[2].weight = 0;
                dead = true;
                StartCoroutine(showText());
            }
        }
        if(successAnimation){
            camera.GetComponents<PostProcessVolume>()[3].weight += 0.022f;
            if(camera.GetComponents<PostProcessVolume>()[3].weight >= 1f){
                sound6.Play(0);
                int mutationChoice = UnityEngine.Random.Range(0, 5);
                if(mutationChoice == 0){
                    invisible = true;
                    transform.GetChild(0).gameObject.SetActive(false);
                    mutationsText.text = "Invisibility";
                    mutationsCountdown.text = "||||||||||||||||||||||||||||||";
                    StartCoroutine(invisibility(30));
                }
                if(mutationChoice == 1){
                    speedy = true;
                    mutationsText.text = "Swiftness";
                    mutationsCountdown.text = "||||||||||||||||||||||||||||||";
                    StartCoroutine(speeding(30));
                }
                if(mutationChoice == 2){
                    rapidFire = true;
                    mutationsText.text = "Automatic";
                    mutationsCountdown.text = "||||||||||||||||||||||||||||||";
                    StartCoroutine(rapid(30));
                }
                if(mutationChoice == 3){
                    hypnosis = true;
                    mutationsText.text = "Hypnosis";
                    mutationsCountdown.text = "||||||||||||||||||||||||||||||";
                    StartCoroutine(hyp(30));
                }
                if(mutationChoice == 4){
                    immunity = true;
                    mutationsText.text = "Immunity";
                    mutationsCountdown.text = "||||||||||||||||||||||||||||||";
                    StartCoroutine(immune(30));
                }
                activeMutation = true;
                successAnimation = false;
                camera.GetComponents<PostProcessVolume>()[3].weight = 0;
                ps.Play();
                mutating = false;
                successText.SetActive(false);
                stopDNA = false;
                StartCoroutine(abc());
            }
        }
        if(animatingMutationsText){
            mutationsText.fontSize -= 0.8f;
            if(mutationsText.fontSize <= 80f){
                animatingMutationsText = false;
            }
        }
        if(insideCell){
            health += 0.01f + activationLevel * 0.002f;
            healthText.text = "" + Mathf.Round(health);
        }
        if(transitioning){
            transition.transform.localScale = new Vector3(transition.transform.localScale.x + 80, transition.transform.localScale.y, transition.transform.localScale.z);
        }
        if(antitransitioning){
            transition.transform.localScale = new Vector3(transition.transform.localScale.x - 80, transition.transform.localScale.y, transition.transform.localScale.z);
            if(transition.transform.localScale.x <= 0){
                antitransitioning = false;
            }
        }
    }
    IEnumerator invisibility(int timer){
        yield return new WaitForSeconds(1f);
        if(timer - 1 == 0){
            mutationsText.text = "";
            mutationsCountdown.text = "";
            activeMutation = false;
            if(insideCell){
                instructionsText2.SetActive(true);
            }
            invisible = false;
            transform.GetChild(0).gameObject.SetActive(true);
        }else{
            mutationsCountdown.text = mutationsCountdown.text.Substring(0, mutationsCountdown.text.Length - 1);
            StartCoroutine(invisibility(timer - 1));
        }  
    }
    IEnumerator speeding(int timer){
        yield return new WaitForSeconds(1f);
        if(timer - 1 == 0){
            mutationsText.text = "";
            mutationsCountdown.text = "";
            activeMutation = false;
            if(insideCell){
                instructionsText2.SetActive(true);
            }
            speedy = false;
        }else{
            mutationsCountdown.text = mutationsCountdown.text.Substring(0, mutationsCountdown.text.Length - 1);
            StartCoroutine(speeding(timer - 1));
        }  
    }
    IEnumerator rapid(int timer){
        yield return new WaitForSeconds(1f);
        if(timer - 1 == 0){
            mutationsText.text = "";
            mutationsCountdown.text = "";
            activeMutation = false;
            if(insideCell){
                instructionsText2.SetActive(true);
            }
            rapidFire = false;
        }else{
            mutationsCountdown.text = mutationsCountdown.text.Substring(0, mutationsCountdown.text.Length - 1);
            StartCoroutine(rapid(timer - 1));
        }  
    }
    IEnumerator hyp(int timer){
        yield return new WaitForSeconds(1f);
        if(timer - 1 == 0){
            mutationsText.text = "";
            mutationsCountdown.text = "";
            activeMutation = false;
            if(insideCell){
                instructionsText2.SetActive(true);
            }
            hypnosis = false;
        }else{
            mutationsCountdown.text = mutationsCountdown.text.Substring(0, mutationsCountdown.text.Length - 1);
            StartCoroutine(hyp(timer - 1));
        }  
    }
    IEnumerator immune(int timer){
        yield return new WaitForSeconds(1f);
        if(timer - 1 == 0){
            mutationsText.text = "";
            mutationsCountdown.text = "";
            activeMutation = false;
            if(insideCell){
                instructionsText2.SetActive(true);
            }
            immunity = false;
        }else{
            mutationsCountdown.text = mutationsCountdown.text.Substring(0, mutationsCountdown.text.Length - 1);
            StartCoroutine(immune(timer - 1));
        }  
    }
    IEnumerator abc(){
        yield return new WaitForSeconds(0.1f);
        stopDNA = false;
        mutationPanel.SetActive(false);
    }
    IEnumerator activate(){
        yield return new WaitForSeconds(nextLevel);
        activationLevel += 1;
        if(!dead) StartCoroutine(activate());
    }
    IEnumerator showText(){
        yield return new WaitForSeconds(0);
        deathPanel.SetActive(true);
    }
    void updatePosition(){
        transform.position += new Vector3(speedX, speedY, 0) * Time.deltaTime;
    }
    void updateSpeed(){
        if(movingUp){
            if(transform.position.y >= 52){
                speedY = 0;
            }else{
                speedY = speed * (speedy ? 3 : 1);
            }
        }
        if(movingDown){
            if(transform.position.x <= -50){
                speedY = 0;
            }else{
                speedY = -speed * (speedy ? 3 : 1);
            }
        }
        if(movingRight){
            if(transform.position.x >= 50){
                speedX = 0;
            }else{
                speedX = speed * (speedy ? 3 : 1);
            }
        }
        if(movingLeft){
            if(transform.position.x <= -50){
                speedX = 0;
            }else{
                speedX = -speed * (speedy ? 3 : 1);
            }
        }
        if((movingRight && movingUp) || (movingRight && movingDown) || (movingLeft && movingUp) || (movingLeft && movingDown)){
            speedX *= 0.75f;
            speedY *= 0.75f;
        }
        if(!movingUp && !movingDown){
            speedY *= (0.99f - Time.deltaTime);
            if(Mathf.Abs(speedY) < 0.2f){
                speedY = 0f;
            }
        }
        if(!movingRight && !movingLeft){
            speedX *= (0.99f - 1.5f * Time.deltaTime);
            if(Mathf.Abs(speedX) < 0.2f){
                speedX = 0f;
            }
        }
    }
    void processInput(){
        if(Input.GetKeyDown("w")){
            movingUp = true;
        }
        if(Input.GetKeyUp("w")){
            movingUp = false;
        }
        if(Input.GetKeyDown("s")){
            movingDown = true;   
        }
        if(Input.GetKeyUp("s")){
            movingDown = false;
        }
        if(Input.GetKeyDown("d")){
            movingRight = true;
        }
        if(Input.GetKeyUp("d")){
            movingRight = false;
        }
        if(Input.GetKeyDown("a")){
            movingLeft = true;   
        }
        if(Input.GetKeyUp("a")){
            movingLeft = false;
        }
        if(Input.GetMouseButtonDown(0)){
            shooting = true;
        }
        if(Input.GetMouseButtonUp(0)){
            shooting = false;
        }
        if(Input.GetKeyDown("m") && mutating && !alreadyMutated){
            stopDNA = true;
            sound4.Play(0);
            instructionsText.SetActive(false);
            alreadyMutated = true;
            GameObject[] moves = GameObject.FindGameObjectsWithTag("movingdna");
            foreach(GameObject move in moves){
                if(Mathf.Abs(move.transform.position.x - transform.position.x) >= 4.75f){
                    Destroy(move);
                }
            }
            GameObject theOne = GameObject.FindGameObjectsWithTag("movingdna")[10];
            GameObject[] statics = GameObject.FindGameObjectsWithTag("dna");
            float minDistance = 999f;
            foreach(GameObject g in statics){
                float distance = Mathf.Abs(g.transform.position.x - theOne.transform.position.x);
                if(distance < minDistance){
                    minDistance = distance;
                }
            }
            if(minDistance < 0.1f){
                StartCoroutine(endSuccess());
            }else{
                StartCoroutine(endFail());
            }
        }
        if(Input.GetKeyDown("m") && insideCell && !mutating && !activeMutation){
            instructionsText2.SetActive(false);
            instructionsText.SetActive(true);
            sound7.Play(0);
            mutate();
            mutating = true;
        }
    }
    IEnumerator endSuccess(){
        successText.SetActive(true);
        yield return new WaitForSeconds(1);
        successAnimation = true;
    }
    IEnumerator endFail(){
        failText.SetActive(true);
        yield return new WaitForSeconds(1);
        foreach(ParticleSystem p in mutateParticles){
            p.Play();
        }
        activationLevel += 2;
        sound5.Play(0);
        mutating = false;
        failText.SetActive(false);
        stopDNA = false;
        yield return new WaitForSeconds(0.1f);
        mutationPanel.SetActive(false);
    }
    void mutate(){
        mutationPanel.SetActive(true);
        Vector3 p = transform.position;
        for(float x = -4.4f; x < 5f; x += 0.5f){
            Instantiate(dnas[UnityEngine.Random.Range(0, dnas.Length)], new Vector3(p.x + x, p.y - 0.5f, 0), Quaternion.identity, mutationPanel.transform);
        }
        for(float x = -5.5f; x < 5f; x += 0.5f){
            Instantiate(movingdnas[UnityEngine.Random.Range(0, dnas.Length)], new Vector3(p.x + x, p.y + 0.8f, 0), Quaternion.identity, mutationPanel.transform);
        }
        StartCoroutine(moveDNA());
    }
    IEnumerator moveDNA(){
        Vector3 p = transform.position;
        Instantiate(movingdnas[UnityEngine.Random.Range(0, dnas.Length)], new Vector3(p.x - 6f, p.y + 0.8f, 0), Quaternion.identity, mutationPanel.transform);
        yield return new WaitForSeconds(0.25f);
        if(!stopDNA) StartCoroutine(moveDNA());
    }
    IEnumerator cooldown(){
        canShoot = false;
        if(rapidFire){
            yield return new WaitForSeconds(0.05f);
        }else{
            yield return new WaitForSeconds(0.3f);
        }
        canShoot = true;
    }
    void updateDirection(){
        Vector3 mouse = Input.mousePosition;
        mouse.z = 0;
        Vector3 newMouse = Camera.main.ScreenToWorldPoint(mouse);
        Vector3 rotation = new Vector3(0, 0, -90 + Mathf.Rad2Deg * Mathf.Atan((newMouse.y - transform.position.y) / (newMouse.x - transform.position.x)) + (newMouse.x - transform.position.x < 0 ? 180 : 0));
        transform.rotation = Quaternion.Euler(rotation);
    }
    void OnTriggerEnter2D(Collider2D other){
        if(!dead && (other.gameObject.tag == "Enemy" || other.gameObject.tag == "EnemyBullet") && !immunity){
            takingDamage = true;
            ppv.weight = 0.4f;
        }
        if(other.gameObject.tag == "Cell"){
            insideCell = true;
            sound3.Play(0);
            if(!activeMutation) instructionsText2.SetActive(true);
            other.gameObject.GetComponent<Cell>().dying = true;
            camera.GetComponents<PostProcessVolume>()[2].weight = 1;
        }
        if(other.gameObject.tag == "Portal"){
            areasInfected += 1;
            sound8.Play(0);
            insideCell = false;
            mutating = false;
            stopDNA = false;
            invisible = true;
            transform.GetChild(0).gameObject.SetActive(false);
            hypnosis = false;
            transitioning = true;
            StartCoroutine(next());
        }
    }
    IEnumerator next(){
        yield return new WaitForSeconds(1);
        activationLevel /= 2;
        transform.GetChild(0).gameObject.SetActive(true);
        invisible = false;
        transitioning = false;
        SceneManager.LoadScene("Game");
    }
    void OnTriggerExit2D(Collider2D other){
        if(other.gameObject.tag == "Enemy" || other.gameObject.tag == "EnemyBullet"){
            takingDamage = false;
            ppv.weight = 0;
        }
        if(other.gameObject.tag == "Cell"){
            insideCell = false;
            instructionsText2.SetActive(false);
            other.gameObject.GetComponent<Cell>().dying = false;
            camera.GetComponents<PostProcessVolume>()[2].weight = 0;
            if(alreadyMutated){
                other.gameObject.GetComponent<Cell>().dying = true;
                other.gameObject.GetComponent<Cell>().health = 0;
            }
            alreadyMutated = false;
        }
    }
    public void home(){
        areasInfected = 1;
        insideCell = false;
        mutating = false;
        stopDNA = false;
        invisible = false;
        hypnosis = false;
        transitioning = false;
        activationLevel = 1;
        SceneManager.LoadScene("Home");
    }
}
