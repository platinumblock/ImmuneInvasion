using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MapManager : MonoBehaviour
{
    public GameObject cell;
    public GameObject particle;
    public GameObject portal;
    void Start(){
        List<Vector3> previous = new List<Vector3>();
        for(int i = 0; i < 21; i++){
            float x = Random.Range(-48f, 48f);
            float y = Random.Range(-48f, 48f);
            while(minDistance(previous, new Vector3(x, y, -1)) < 6){
                x = Random.Range(-48f, 48f);
                y = Random.Range(-48f, 48f);
            }
            if(i == 20){
                Instantiate(portal, new Vector3(x, y, -1), Quaternion.identity);
            }else{
                Instantiate(cell, new Vector3(x, y, -1), Quaternion.identity);
            }
            previous.Add(new Vector3(x, y, -1));
        }
        for(int i = 0; i < 4000; i++){
            float x = Random.Range(-50f, 50f);
            float y = Random.Range(-50f, 50f);
            Instantiate(particle, new Vector3(x, y, 0), Quaternion.identity);
        }
    }
    void Update(){
        
    }
    float minDistance(List<Vector3> previous, Vector3 current){
        float dist = 9999;
        foreach(Vector3 prev in previous){
            float d = Mathf.Sqrt(Mathf.Pow(prev.x - current.x, 2) + Mathf.Pow(prev.y - current.y, 2));
            if(d < dist){
                dist = d;
            }
        }
        return dist;
    }
}
