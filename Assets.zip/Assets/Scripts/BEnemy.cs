using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BEnemy : MonoBehaviour
{
    float speed = 2.9f;
    GameObject player;
    float maxHealth;
    float health;
    public GameObject healthBar;
    public ParticleSystem ps;
    bool dead = false;
    AudioSource sound;
    void Start(){
        maxHealth = 50f + Player.activationLevel * 4;
        health = maxHealth;
        player = GameObject.Find("Player");
        sound = GetComponent<AudioSource>();
    }
    void Update(){
        if(!Player.insideCell && !dead && !Player.dead && !Player.invisible){
            Vector3 rotation = new Vector3(0, 0, -90 + Mathf.Rad2Deg * Mathf.Atan((player.transform.position.y - transform.position.y) / (player.transform.position.x - transform.position.x)) + (player.transform.position.x - transform.position.x < 0 ? 180 : 0));
            transform.rotation = Quaternion.Euler(rotation);
            if(Player.hypnosis){
                transform.position -= transform.up * speed * Time.deltaTime;
            }else{
                transform.position += transform.up * speed * Time.deltaTime;
            }
        }
        speed = 1f + Player.activationLevel * 0.1f;
        /*
        if(Player.dead){
            Destroy(healthBar);
            Destroy(gameObject);
        }
        */
    }
    void OnTriggerEnter2D(Collider2D other){
        if(other.gameObject.tag == "PlayerBullet"){
            Destroy(other.gameObject);
            sound.Play(0);
            health -= 20f;
            healthBar.transform.localScale = new Vector3(0.8f * (health / maxHealth), 0.1f, 1);
            if(health/maxHealth <= 0.66f){
                healthBar.GetComponent<SpriteRenderer>().color = new Color(255, 255, 0);
            }
            if(health/maxHealth <= 0.33f){
                healthBar.GetComponent<SpriteRenderer>().color = new Color(255, 0, 0);
            }
            if(health <= 0){
                transform.localScale = new Vector3(0, 0, 0);
                healthBar.transform.localScale = new Vector3(0, 0, 0);
                ps.Play();
                dead = true;
                StartCoroutine(die());
            }
        }
    }
    IEnumerator die(){
        yield return new WaitForSeconds(1);
        Destroy(transform.parent.gameObject);
    }
}
