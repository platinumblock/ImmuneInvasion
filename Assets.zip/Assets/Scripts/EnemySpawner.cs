using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemySpawner : MonoBehaviour
{
    public GameObject player;
    public GameObject[] enemies;
    float spawnRate = 1f;
    void Start()
    {
        StartCoroutine(spawn());
    }
    void Update()
    {
        spawnRate = 0.2f + Player.activationLevel * 0.02f;
    }
    IEnumerator spawn(){
        yield return new WaitForSeconds(1f / spawnRate);
        Vector3 v = player.transform.position;
        float x = Random.Range(-30f, 30f);
        while(Mathf.Abs(x) < 10 || Mathf.Abs(v.x + x) > 50){
            x = Random.Range(-30f, 30f);
        }
        float y = Random.Range(-30f, 30f);
        while(Mathf.Abs(y) < 10 || Mathf.Abs(v.y + y) > 50){
            y = Random.Range(-30f, 30f);
        }
        int enemyChoice = Random.Range(0, enemies.Length);
        Instantiate(enemies[enemyChoice], new Vector3(v.x + x, v.y + y, v.z), Quaternion.identity);
        StartCoroutine(spawn());
    }
}
