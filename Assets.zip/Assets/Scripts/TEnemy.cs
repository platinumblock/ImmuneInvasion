using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TEnemy : MonoBehaviour
{
    float speed = 1.5f;
    float shootingSpeed = 2f;
    GameObject player;
    float maxHealth;
    float health;
    public GameObject healthBar;
    public GameObject tBullet;
    public ParticleSystem ps;
    bool dead = false;
    AudioSource sound;
    void Start(){
        maxHealth = 30f + Player.activationLevel * 3;
        health = maxHealth;
        StartCoroutine(shoot());
        player = GameObject.Find("Player");
        sound = GetComponent<AudioSource>();
    }
    void Update(){
        if(!Player.insideCell && !dead && !Player.dead && !Player.invisible){
            Vector3 rotation = new Vector3(0, 0, -90 + Mathf.Rad2Deg * Mathf.Atan((player.transform.position.y - transform.position.y) / (player.transform.position.x - transform.position.x)) + (player.transform.position.x - transform.position.x < 0 ? 180 : 0));
            transform.rotation = Quaternion.Euler(rotation);
            if(Player.hypnosis){
                transform.position -= transform.up * speed * Time.deltaTime;
            }else{
                transform.position += transform.up * speed * Time.deltaTime;
            }
        }
        speed = 0.6f + Player.activationLevel * 0.05f;
        shootingSpeed = 0.5f + Player.activationLevel * 0.08f;
        /*
        if(Player.dead){
            Destroy(healthBar);
            Destroy(gameObject);
        }
        */
    }
    IEnumerator shoot(){
        yield return new WaitForSeconds(1f / shootingSpeed);
        Vector3 rotation = new Vector3(0, 0, -90 + Mathf.Rad2Deg * Mathf.Atan((player.transform.position.y - transform.position.y) / (player.transform.position.x - transform.position.x)) + (player.transform.position.x - transform.position.x < 0 ? 180 : 0));
        float distance = Mathf.Sqrt(Mathf.Pow(Mathf.Abs(player.transform.position.x - transform.position.x), 2) + Mathf.Pow(Mathf.Abs(player.transform.position.y - transform.position.y), 2));
        if(!Player.insideCell && distance < 7 && !dead && !Player.invisible){
            if(Player.hypnosis){
                Instantiate(tBullet, transform.position, Quaternion.Euler(-rotation));
            }else{
                Instantiate(tBullet, transform.position, Quaternion.Euler(rotation));
            }
        }
        StartCoroutine(shoot());
    }
    void OnTriggerEnter2D(Collider2D other){
        if(other.gameObject.tag == "PlayerBullet"){
            Destroy(other.gameObject);
            sound.Play(0);
            health -= 20f;
            healthBar.transform.localScale = new Vector3(0.8f * (health / maxHealth), 0.1f, 1);
            if(health/maxHealth <= 0.66f){
                healthBar.GetComponent<SpriteRenderer>().color = new Color(255, 255, 0);
            }
            if(health/maxHealth <= 0.33f){
                healthBar.GetComponent<SpriteRenderer>().color = new Color(255, 0, 0);
            }
            if(health <= 0){
                transform.localScale = new Vector3(0, 0, 0);
                healthBar.transform.localScale = new Vector3(0, 0, 0);
                ps.Play();
                dead = true;
                StartCoroutine(die());
            }
        }
    }
    IEnumerator die(){
        yield return new WaitForSeconds(1);
        Destroy(transform.parent.gameObject);
    }
}
